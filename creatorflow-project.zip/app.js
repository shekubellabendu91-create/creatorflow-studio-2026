const topic = document.querySelector('#topic');
const platform = document.querySelector('#platform');
const tone = document.querySelector('#tone');
const generate = document.querySelector('#generate');
const error = document.querySelector('#error');
const results = document.querySelector('#results');

const platformNames = {
  tiktok: 'TikTok',
  instagram: 'Instagram Reels',
  youtube: 'YouTube Shorts',
  facebook: 'Facebook Reels'
};

const toneOpeners = {
  bold: 'Stop scrolling—this is something you should know about',
  friendly: 'Here is a simple way to think about',
  educational: 'Let’s break down',
  motivational: 'If you are starting from zero, remember this about'
};

function clean(text) {
  return text.trim().replace(/\s+/g, ' ');
}

function makePack(subject, toneKey, platformKey) {
  const name = platformNames[platformKey];
  const opener = toneOpeners[toneKey];

  const hook = `${opener} ${subject}.`;
  const script = [
    `HOOK: ${hook}`,
    '',
    `PROBLEM: A lot of people are interested in ${subject}, but they do not know where to begin.`,
    `VALUE: Start with one clear goal, learn the basics, test your idea, and improve from real feedback. Do not try to do everything at once.`,
    `EXAMPLE: Pick one small action you can complete today related to ${subject}. Track what happens, then use the result to decide your next step.`,
    `ENDING: Keep it simple, stay consistent, and focus on progress rather than perfection.`,
    '',
    `This script is designed for ${name} and can be adjusted to your own experience.`
  ].join('\n');

  const caption = `${subject} made simple. Start small, learn as you go, and keep improving. What would you add to this list?`;

  const cta = toneKey === 'motivational'
    ? 'Follow for more practical ideas and share this with someone who needs the reminder.'
    : 'Save this for later and follow for more practical content.';

  const tags = ['#ContentCreator', '#CreatorTips', '#LearnOnline', '#DigitalSkills', '#ContentIdeas', '#CreatorFlow']
    .join(' ');

  return {hook, script, caption, cta, hashtags: tags};
}

generate.addEventListener('click', () => {
  const subject = clean(topic.value);
  error.textContent = '';

  if (subject.length < 5) {
    error.textContent = 'Enter a topic with at least 5 characters.';
    return;
  }

  const pack = makePack(subject, tone.value, platform.value);
  Object.entries(pack).forEach(([key, value]) => {
    document.querySelector(`#${key}`).textContent = value;
  });
  results.hidden = false;
  results.scrollIntoView({behavior:'smooth', block:'start'});
});

document.querySelectorAll('[data-copy]').forEach(button => {
  button.addEventListener('click', async () => {
    const key = button.dataset.copy;
    const value = document.querySelector(`#${key}`).textContent;
    try {
      await navigator.clipboard.writeText(value);
      const old = button.textContent;
      button.textContent = 'Copied!';
      setTimeout(() => button.textContent = old, 1200);
    } catch {
      button.textContent = 'Select & copy';
    }
  });
});
